var x;

function myFunction() {
    x = getId("myLinks");
    if (x.style.display === "block") {
        x.style.display = "none";
    } else {
        x.style.display = "block";
    }
}

function projectsHtml() {
    x = getId("html-projects");
    if (x.style.display === "block") {
        x.style.display = "none";
    } else {
        x.style.display = "block";
    }
}

function projectsJs() {
    x = getId("js-projects");
    if (x.style.display === "block") {
        x.style.display = "none";
    } else {
        x.style.display = "block";
    }
}

function projectsBackend() {
    x = getId("backend-projects");
    if (x.style.display === "block") {
        x.style.display = "none";
    } else {
        x.style.display = "block";
    }
}

function aboutMoretext() {
    x = getId("about-moretext")
    if (x.style.display === "block") {
        x.style.display = "none";
    } else {
        x.style.display = "block";
    }
}


function getId(id) {
    return document.getElementById(id);
}